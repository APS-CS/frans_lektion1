#4
name = "Amos"
age = 18
temp = 9.8
is_student = True

print(name, type(name))
print(age, type(age))
print(temp, type(temp))
print(is_student, type(is_student))

#5
a = 15
b = 4

summa = a + b
differens = a - b
produkt = a * b
kvot = a / b
golvkvot = a // b
moduluskvot = a % b
kvadrat = a ** b

print(summa)
print(differens)
print(produkt)
print(kvot)
print(golvkvot)
print(moduluskvot)
print(kvadrat)

#6
string_uppgift = "Hello, World!"

print(string_uppgift[0])
print(string_uppgift[7:12])
print(string_uppgift[::2])
print(string_uppgift[::-1])