# Kapitel 1
Variabler, operatörer och strängar
