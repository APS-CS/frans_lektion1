# x = 5
# print(x)

#x = 5
#y = 3.14
#namn = "Bobbo"
#is_student = True

#lista = ["äpple", "banan", "päron", 8]

#koordinater = (10, 20)

#person = {"namn": "Bobbo", "ålder": 37}

#sets - Kan bara innehålla unika element, upprepade värden skipas. Det raderar dubbletter ur utskrivning

#tal = {1, 2, 3, 4, 5}

#x = 10
#print(x)
#X = "Hej"
#print(x)

a = 10
b = 5
summa = a + b
differens = a - b
produkt = a*b
kvot = a / b
heltalskvot = a // b
modulus = b % a

print(summa)
print(differens)
print(produkt)
print(kvot)
print(heltalskvot)
print(modulus)

#bas = 2
#exponent = 3
#results = bas ** exponent

#print("Results is:",results)

#results = 10 + 2 * 3
#print("Results is", results)

#results = (10 + 2) * 3
#print ("Results is", results)

#a = 15
#b = 4
#c = 2
#results = (a - b) * c + b / c 
#print("Results is:",results)

#x = 5
#x = x + 1
#print("x is:",x)

#x = 5
#x += 1

#print("x is:", x)

#x -= 5

#print("x is now:",)

#x = 5
#x -= 2
#print ("x is now:", x)

#a = 5.5
#b = 2.0

#sums = a + b
#product = a * b
#print("Sums is:", sums)
#print("Product is:", product)

#a = 5
#b = 5
#results = a == b
#print("Results are equal?", results)


#a = 5
#b = 3
#results = a != b
#print("Results are not equal?", results)

#a = 10
#b = 5
#results = a > b
#print("Is a greater than b?", results)


#ålder = 25
#temperatur = 36.6
#namn = "Alice"
#print(namn[0])
#print(namn[1])
#print(namn[-1])

#sekvens[start:stop:step]
#str = "Hello, World!"
#print(str[0:5])
##print(str[7:12])
#print(str[::2])
#print(str[::-1])

#str1 = "Hello"
#str2 = "World"
#str3 = str1 + ", " + str2 + "! "
#print(str3 * 3 )

#str = "Python"

#print(len(str))

#str = "Hello, World!"
#print("World" in str)
#print("Python" in str)
