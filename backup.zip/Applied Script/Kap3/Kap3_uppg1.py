############Uppgift 1 FizzBuzz#############
for loopen in range(1, 101):
    if loopen % 3 == 0 and loopen % 3 == 0:
        print("FizzBuzz")
    elif loopen % 3 == 0:
        print("Fizz")
    elif loopen % 5 == 0:
        print("Buzz")
    else:
        print(loopen)