import math_op

print(math_op.add(38, 99))
print(math_op.substract(122, 55))