def add(a, b):
    return a+b

def substract (a, b):
    return a - b

def main():
    print("Math operations")
    print(add(5, 3))
    print(substract(10, 5))


if __name__ == "__main__":
    main()