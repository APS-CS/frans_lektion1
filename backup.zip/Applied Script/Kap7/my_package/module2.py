def function2():
    return "Function 2 från module2"