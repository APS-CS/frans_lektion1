def function1():
    return "Function 1 från module1"