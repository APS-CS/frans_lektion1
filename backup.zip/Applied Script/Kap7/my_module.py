def greet(name):
    return f"Hej {name}"

def add(a, b):
    return a + b


PI = 3.14